﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField]
    GameObject wallPrefab;

    [SerializeField]
    GameObject testObj;

    Vector3[,,] nodes = new Vector3[3,3,3];

	// Use this for initialization
	void Awake ()
    {
        for (int x = -1; x <= 1; x++)
        {
            for (int y = -1; y <= 1; y++)
            {
                for (int z = -1; z <= 1; z++)
                {
                    nodes[x + 1, y + 1, z + 1] = new Vector3(x * 2, y * 2, z * 2);
                }
            }
        }

        //foreach (Vector3 v in nodes)
        //{
        //    Instantiate(testObj, v, Quaternion.identity);
        //}
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    public Vector3[,,] GetNodes()
    {
        return nodes;
    }
}