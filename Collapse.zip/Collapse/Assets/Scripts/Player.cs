﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    GameManager gameManager;

    Vector3[,,] nodes;
    Vector3 currentPosition;
    Vector3 destination;

    Vector2 floorInput;

    float lerpSpeed = 20f;

	// Use this for initialization
	void Start () {
        gameManager = FindObjectOfType<GameManager>();

        nodes = gameManager.GetNodes();

        currentPosition = GetCurrentPosition(transform.position);
        destination = nodes[1, 1, 1];

        print(destination);

    }
	
	// Update is called once per frame
	void Update ()
    {
        floorInput = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical")).normalized;

    }

    private void Move(Vector3 target)
    {

    }

    private Vector3 GetCurrentPosition(Vector3 worldPos)
    {
        int x = Mathf.RoundToInt(worldPos.x);
        int y = Mathf.RoundToInt(worldPos.y);
        int z = Mathf.RoundToInt(worldPos.z);

        return new Vector3(x, y, z);
    }
}
