﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeManager : MonoBehaviour
{
    Material mat;
    [SerializeField]
    float speedMod = 5;

    // Use this for initialization
    void Start () {
        mat = GetComponent<Renderer>().material;
	}
	
	// Update is called once per frame
	void Update ()
    {
        float hueVal = (Mathf.Sin(Time.time * speedMod) * 180f) + 180f;

        mat.SetColor("color", Color.HSVToRGB(hueVal / 360f, 255, 255));

    }
}
