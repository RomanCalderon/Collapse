﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    float destroyDelay;
    float speed;
    bool startMovement = false;

    [SerializeField]
    Material wallMaterial;

    [SerializeField]
    GameObject[] tiles = new GameObject[9];

	// Use this for initialization
	void Start ()
    {
        StartCoroutine(DestroyTimer());
        StartCoroutine(MoveDelay());

        transform.position += transform.forward * -0.06f;

        StartCoroutine(FadeIn());
	}

    private void Update()
    {
        if (startMovement)
            transform.Translate(-Vector3.forward * Time.deltaTime * speed, Space.Self);
    }

    public void Initialize(int tile, float rate)
    {
        destroyDelay = rate / 1.25f;
        speed = 10 / rate;
        transform.GetChild(tile).gameObject.SetActive(false);
    }

    private IEnumerator MoveDelay()
    {
        yield return new WaitForSeconds(0.5f);
        startMovement = true;
    }

    IEnumerator DestroyTimer()
    {
        yield return new WaitForSeconds(destroyDelay);
        Destroy(gameObject);
    }

    IEnumerator FadeIn()
    {
        float alpha = 0.0f;

        float red = Random.Range(0.0f, 1.0f);
        float green = Random.Range(0.0f, 1.0f);
        float blue = Random.Range(0.0f, 1.0f);
        Color wallColor = new Color(red, green, blue, 0.0f);

        while (alpha < 0.75f)
        {
            foreach (GameObject t in tiles)
            {
                wallColor.a = alpha;
                wallMaterial.color = wallColor;
                alpha += Time.deltaTime * 0.65f;
            }
            yield return null;
        }
    }
}
